#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2025 Melle Koning
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# ChatWithTree.py
import logging
import re

import ChatWithTreeConfig
import gi
from AsyncChatService import AsyncChatService
from chatwithllm import ChatResponse, ReplyItem, YieldType
from gi.repository import Gdk, GLib, Gtk
from gramps.gen.const import GRAMPS_LOCALE as glocale
from gramps.gen.plug import Gramplet
from gramps.gui.editors import EditFamily, EditPerson

LOG = logging.getLogger(".")
LOG.debug("loading chatwithtree")
# ==============================================================================
# Standard Python libraries
# ==============================================================================

gi.require_version("Gtk", "3.0")
# ==============================================================================
# GRAMPS API
# ==============================================================================

_ = glocale.get_addon_translator(__file__).gettext

LOG.debug("ChatWithTree file header loaded successfully.")

ONE_SECOND = 1000  # milliseconds


# ==============================================================================
# Gramplet Class Definition
# ==============================================================================
class ChatWithTreeMCPClass(Gramplet):
    """
    A simple interactive Gramplet that takes user input and provides a reply.

    This version uses a Gtk.ListBox to create a dynamic, chat-like interface
    with styled message "balloons" for user input and system replies.
    """

    def __init__(self, parent=None, **kwargs):
        """
        The constructor for the Gramplet.
        We call the base class constructor here. The GUI is built in the
        init() method.
        """
        # Call the base class constructor. This is a mandatory step.
        Gramplet.__init__(self, parent, **kwargs)

    def init(self):
        """
        This method is called by the Gramps framework after the Gramplet
        has been fully initialized. We build our GUI here.
        """
        # Build our custom GUI widgets.
        self.vbox = self._build_gui()
        # The Gramplet's container widget is found via `self.gui`.
        # We first remove the default textview...
        self.gui.get_container_widget().remove(self.gui.textview)
        # ... and then we add our new vertical box.
        self.gui.get_container_widget().add(self.vbox)
        # Show all widgets.
        self.vbox.show()
        # db change signal
        self.dbstate.connect("database-changed", self.change_db)
        self.chat_service = None

    def change_db(self, db):
        """
        This method is called when the database is opened or closed.
        The 'dbstate' parameter is the current database state object.
        """
        # Add the initial message to the list box.

        if self.dbstate.db:
            try:
                active_db_name = self.dbstate.db.get_dbname()
                if active_db_name:
                    dbChangeMessage = ReplyItem(
                        type=YieldType.PARTIAL,
                        data=ChatResponse(
                            text=_("Database change detected %s.") % active_db_name
                        ),
                    )
                    self._add_message_row(dbChangeMessage)
                    self.chat_service = AsyncChatService(active_db_name)
            except (TypeError, ValueError, KeyError) as e:
                LOG.error(f"Failed to initialize AsyncChatService: {e}")
                self.chat_service = None  # Ensure it's None on failure
                return
        else:
            LOG.error("Database is closed. Chatbot logic is reset.")
            self.chat_service = None

    def _build_gui(self):
        """
        Creates all the GTK widgets for the Gramplet's user interface.
        Returns the top-level container widget.
        """
        # Create the main vertical box to hold all our widgets.
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)

        # -------------------
        # 1. Chat History Section
        # -------------------
        # We use a Gtk.ListBox to hold our chat "balloons".
        self.chat_listbox = Gtk.ListBox()
        # Set a name for CSS styling.
        self.chat_listbox.set_name("chat-listbox")
        # Ensure the listbox is a single-column list.
        self.chat_listbox.set_selection_mode(Gtk.SelectionMode.NONE)

        # We need a reference to the scrolled window to control its scrolling.
        self.scrolled_window = Gtk.ScrolledWindow()
        self.scrolled_window.set_hexpand(True)
        self.scrolled_window.set_vexpand(True)
        self.scrolled_window.add(self.chat_listbox)
        vbox.pack_start(self.scrolled_window, True, True, 0)

        # Apply CSS styling for the chat balloons.
        self._apply_css_styles()

        # -------------------
        # 2. Input Section
        # -------------------
        input_hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)

        self.input_entry = Gtk.Entry()
        self.input_entry.set_placeholder_text(_("Type a message..."))
        self.input_entry.connect("activate", self.on_process_button_clicked)
        input_hbox.pack_start(self.input_entry, True, True, 0)

        self.process_button = Gtk.Button(label=_("Send"))
        self.process_button.connect("clicked", self.on_process_button_clicked)
        input_hbox.pack_start(self.process_button, False, False, 0)

        self.settings_button = Gtk.Button(label=_("Settings"))
        self.settings_button.connect("clicked", self.on_settings_button_clicked)
        input_hbox.pack_start(self.settings_button, False, False, 0)

        vbox.pack_start(input_hbox, False, False, 0)

        # Add the initial message to the list box.
        initMessage = ReplyItem(
            type=YieldType.PARTIAL,
            data=ChatResponse(
                text=_(
                    "Chat with Tree initialized. \
                Type /help for help."
                )
            ),
        )
        self._add_message_row(initMessage)

        return vbox

    def _apply_css_styles(self):
        """
        Defines and applies CSS styles to the Gramplet's widgets.
        """
        css_provider = Gtk.CssProvider()
        # The message-bubble backgrounds are intentionally light pastels
        # (Mantis 14143) -- they colour-code message type and were chosen
        # against a white parent. The foreground was implicitly the GTK
        # theme's default, which is LIGHT under a dark theme -- so the
        # result was light-on-light text. Lock the foreground to black
        # for the bubble classes so the contrast holds regardless of the
        # active GTK theme. The chat listbox background is also locked
        # so the empty-chat area doesn't go dark-on-white in dark mode.
        css = """
        #chat-listbox {
            background-color: white;
            color: black;
        }
        .message-box {
            background-color: #f0f0f0; /* Default background */
            color: black;
            padding: 10px;
            margin: 5px;
            border-radius: 15px;
        }
        .user-message-box {
            background-color: #dcf8c6; /* Light green for user messages */
            color: black;
        }
        .tree-reply-box {
            background-color: #d1e2f4; /* Light blue for replies */
            color: black;
        }
        .error-reply-box {
            background-color: #f4e2d1; /* Light red for errors */
            color: black;
        }
        .tree-toolcall-box {
            background-color: #fce8b2; /* Light yellow for tool calls */
            color: black;
        }

        """
        css_provider.load_from_data(css.encode("utf-8"))
        screen = Gdk.Screen.get_default()
        context = Gtk.StyleContext()
        context.add_provider_for_screen(
            screen, css_provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

        # We need to set up a style context on the chat listbox
        style_context = self.chat_listbox.get_style_context()
        style_context.add_class("message-box")

    def _markdown_to_pango(self, text, entities=None):
        """
        Converts Markdown to Pango and safely injects entity links
        without nesting tags.
        """
        # 1. Normalize and Escape (Must be first)
        text = text.replace("\u202f", " ").replace("\u00a0", " ")
        text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

        placeholders = {}
        linked_handles = set()

        if entities:
            # Sort by name length descending to handle "John Smith" before "John"
            sorted_entities = sorted(entities, key=lambda x: len(x.name), reverse=True)

            for i, entity in enumerate(sorted_entities):
                link_uri = f"{entity.entity_type}:{entity.handle}"

                # Create unique keys for this specific entity
                name_key = f"##NAME_{i}##"
                handle_key = f"##HNDL_{i}##"

                # --- Pass 1: Replace raw text with placeholders ---
                # We replace the literal handle and literal name in the text
                if entity.handle in text:
                    text = text.replace(entity.handle, handle_key)
                    # Store the final Pango version for later
                    linkref = (
                        f'<a href="{link_uri}">'
                        f'<span font_family="monospace">{entity.handle}</span>'
                        "</a>"
                    )
                    placeholders[handle_key] = linkref
                    linked_handles.add(entity.handle)

                if entity.name in text:
                    text = text.replace(entity.name, name_key)
                    placeholders[name_key] = (
                        f'<a href="{link_uri}"><b>{entity.name}</b></a>'
                    )
                    linked_handles.add(entity.handle)

        # 2. Render Markdown (Bold, Italics, etc.)
        # Because we use placeholders like ##NAME_0##, Markdown regex won't
        # find names/handles and accidentally break them.
        text = re.sub(r"^####\s+(.*?)$", r"\n<b>\1</b>", text, flags=re.MULTILINE)
        text = re.sub(
            r"^###\s+(.*?)$", r"\n<b><big>\1</big></b>", text, flags=re.MULTILINE
        )
        text = re.sub(
            r"^##\s+(.*?)$",
            r'\n<b><span size="large">\1</span></b>',
            text,
            flags=re.MULTILINE,
        )
        text = re.sub(
            r"^#\s+(.*?)$",
            r'\n<b><span size="x-large">\1</span></b>',
            text,
            flags=re.MULTILINE,
        )
        text = re.sub(r"\*\*(.*?)\*\*", r"<b>\1</b>", text)
        text = re.sub(r"\*(.*?)\*", r"<i>\1</i>", text)
        text = re.sub(
            r"`(.*?)`",
            r'<span font_family="monospace" background="#eeeeee">\1</span>',
            text,
        )
        text = re.sub(r"^(\s*)[\-\*]\s+", r"\1• ", text, flags=re.MULTILINE)

        # 3. Final Pass: Swap placeholders back for real Pango Links
        for key, pango_html in placeholders.items():
            text = text.replace(key, pango_html)

        unlinked = [e for e in entities if e.handle not in linked_handles]

        if unlinked:
            text += "\n---\n<i>Related Records:</i>"
            for e in unlinked:
                link_uri = f"{e.entity_type}:{e.handle}"
                text += f'\n• <a href="{link_uri}"><b>{e.name}</b></a>'

        return text

    def _add_message_row(self, reply: ReplyItem) -> Gtk.Label:
        """
        Creates a new message "balloon" widget and adds it to the listbox.
        """
        # Create a horizontal box to act as the message container.
        hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        hbox.set_spacing(6)

        # Create the message "balloon" box.
        message_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        message_box.get_style_context().add_class("message-box")

        # Create the label for the text.
        message_label = Gtk.Label()

        # Decide whether to render Markdown
        if reply.type in (YieldType.USER, YieldType.PARTIAL, YieldType.FINAL):
            message_label.set_markup(
                self._markdown_to_pango(reply.data.text, reply.data.metadata)
            )
            if reply.data.has_links:
                message_label.connect("activate-link", self.on_handle_clicked)
        else:
            # Tool calls and errors remain plain text
            message_label.set_text(reply.data.text)

        message_label.set_halign(Gtk.Align.START)
        message_label.set_line_wrap(True)
        message_label.set_selectable(True)
        message_label.set_max_width_chars(80)
        message_label.set_selectable(True)
        message_box.pack_start(message_label, True, True, 0)

        if reply.type == YieldType.USER:
            message_box.get_style_context().add_class("user-message-box")
            # Align the message balloon to the right.
            hbox.set_halign(Gtk.Align.END)
        elif reply.type in (YieldType.PARTIAL, YieldType.TOOL_CALL):
            message_box.get_style_context().add_class("tree-toolcall-box")
            # Align the message balloon to the left.
            hbox.set_halign(Gtk.Align.CENTER)

        elif reply.type == YieldType.FINAL:
            message_box.get_style_context().add_class("tree-reply-box")
            # Align the message balloon to the left.
            hbox.set_halign(Gtk.Align.START)
        elif reply.type == YieldType.ERROR:
            message_box.get_style_context().add_class("error-reply-box")
            # Align the message balloon to the left.
            hbox.set_halign(Gtk.Align.START)

        # Add the message balloon to the main horizontal container.
        hbox.add(message_box)

        # Add the whole row to the listbox.
        self.chat_listbox.add(hbox)
        self.chat_listbox.show_all()

        return message_label

    def on_handle_clicked(self, label, uri):
        try:
            # uri is "Person:f51cfe..." or "Family:f51cfe..."
            etype, handle = uri.split(":", 1)
            db = self.dbstate.db

            if etype == "Person":
                person = db.get_person_from_handle(handle)
                if person:
                    # Open the Person Editor
                    EditPerson(self.dbstate, self.uistate, [], person)

            elif etype == "Family":
                family = db.get_family_from_handle(handle)
                if family:
                    # Open the Family Editor
                    EditFamily(self.dbstate, self.uistate, [], family)

        except (TypeError, ValueError, KeyError) as e:
            # We use LOG.error as per your existing pattern
            LOG.error(f"Failed to open editor for {uri}: {e}")

        return True

    def scroll_to_bottom(self):
        """
        Helper function to scroll the listbox to the end.
        This runs on the main GTK thread after a redraw.
        """
        adj = self.scrolled_window.get_vadjustment()
        adj.set_value(adj.get_upper())

        # Return False to run the callback only once
        return GLib.SOURCE_REMOVE

    def _check_queue_for_reply(self):
        """
        Pulls the next available result from the AsyncChatService's internal
        result queue on the main GTK thread to update the UI.

        This method runs repeatedly via GLib.idle_add until the job is done.
        """
        # Safety check
        if self.chat_service is None:
            LOG.error("Chat service is unexpectedly None in _check_queue_for_reply.")
            return GLib.SOURCE_REMOVE

        try:
            # Non-blocking attempt to get the next result from the worker thread's queue.
            # This result will be ReplyItem or None (the sentinel).
            reply: ReplyItem | None = self.chat_service.get_next_result_from_queue()

            if reply is None:
                # Queue is empty. Check the status of the background job.
                if self.chat_service.is_processing():
                    # Job is still running, check the queue again later.
                    return GLib.SOURCE_CONTINUE
                else:
                    # Job is finished (sentinel already processed or queue is empty
                    # after job completion). Stop the idle handler.
                    return GLib.SOURCE_REMOVE

            # If we reached here, 'reply' is of type ReplyItem tuple
            if reply.type == YieldType.PARTIAL:
                self._add_message_row(reply)

            elif reply.type == YieldType.TOOL_CALL:
                # Append to an existing label for streaming effect, or create a new one
                if self.current_tool_call_label is None:
                    self.current_tool_call_label = self._add_message_row(reply)
                else:  # This is a subsequent tool call. Update the existing label.
                    existing_text = self.current_tool_call_label.get_text()
                    self.current_tool_call_label.set_text(
                        existing_text + " " + reply.data.text
                    )

            elif reply.type == YieldType.FINAL or reply.type == YieldType.ERROR:
                # Final reply from the chatbot.
                self._add_message_row(reply)

            # Since we successfully retrieved and processed an item,
            # we immediately check the queue again for the next item.
            return GLib.SOURCE_CONTINUE

        except (TypeError, ValueError, KeyError) as e:
            # Handle unexpected errors on the main GTK thread
            error_message = f"Critical UI Error: {type(e).__name__} - {e}"
            LOG.exception(error_message)
            exceptionReply = ReplyItem(
                type=YieldType.ERROR,
                data=ChatResponse(text=f"Application Error. {error_message}"),
            )
            self._add_message_row(exceptionReply)

            return GLib.SOURCE_REMOVE  # Stop the process on error

    def on_settings_button_clicked(self, widget):
        try:
            self._show_settings_dialog()
        except (TypeError, ValueError, KeyError) as e:
            LOG.error(f"Settings dialog failed: {e}")

    def _show_settings_dialog(self):
        try:
            self.dialog, self.grid, self.entries = self._build_dialog_grid()
            # Fetch and cache model lists from providers with API keys set (once, then reuse)
            if not ChatWithTreeConfig._MODEL_OPTIONS_CACHE:
                self._fetch_and_cache_model_lists()
            self._add_settings_rows()
            self.dialog.show_all()
            resp = self.dialog.run()
            if resp == Gtk.ResponseType.OK:
                self._persist_settings()
            self.dialog.destroy()
        except (TypeError, ValueError, KeyError) as e:
            import logging

            logging.getLogger(".").error(f"[Settings] Dialog failed: {e}")

    def _build_dialog_grid(self):
        import gi

        gi.require_version("Gtk", "3.0")
        from gi.repository import Gtk

        dialog = Gtk.Dialog(
            title="ChatWithTreeMCP Settings",
            buttons=(
                Gtk.STOCK_CANCEL,
                Gtk.ResponseType.CANCEL,
                Gtk.STOCK_OK,
                Gtk.ResponseType.OK,
            ),
        )
        dialog.set_default_size(650, 500)
        box = dialog.get_content_area()
        box.set_spacing(6)
        grid = Gtk.Grid(column_spacing=6, row_spacing=6)
        box.pack_start(grid, False, False, 0)
        return dialog, grid, {}

    def _add_settings_rows(self):
        import gi

        gi.require_version("Gtk", "3.0")
        from gi.repository import Gtk

        settings_items = list(ChatWithTreeConfig.SETTINGS_MAP.items())
        self.entries = {}
        for i, (key, (label_text, default_val)) in enumerate(settings_items):
            lbl = Gtk.Label(label=label_text)
            lbl.set_halign(Gtk.Align.END)
            lbl.set_xalign(1)
            if key == "loop_limit":
                combo = Gtk.ComboBoxText()
                for val in ["6", "8", "10", "12"]:
                    combo.append_text(val)
                combo.set_active(0)
                current = (
                    str(ChatWithTreeConfig.load_setting(key))
                    if ChatWithTreeConfig.load_setting(key) is not None
                    else str(default_val)
                )
                for idx, val in enumerate(["6", "8", "10", "12"]):
                    if val == str(current):
                        combo.set_active(idx)
                self.entries[key] = combo
                self.grid.attach(lbl, 0, i, 1, 1)
                self.grid.attach(combo, 1, i, 1, 1)
            else:
                if key == "model_name":
                    combo = self._build_modeldropdown()
                    current_model = ChatWithTreeConfig.load_setting("model_name") or ""
                    combo.set_active(0)
                    for idx, val in enumerate(self._build_modeldropdown_options()):
                        if val == current_model:
                            combo.set_active(idx)
                    self.entries[key] = combo
                    self.grid.attach(lbl, 0, i, 1, 1)
                    self.grid.attach(combo, 1, i, 1, 1)
                else:
                    ent = Gtk.Entry()
                    ent.set_hexpand(True)
                    current = (
                        str(ChatWithTreeConfig.load_setting(key))
                        if ChatWithTreeConfig.load_setting(key) is not None
                        else ""
                    )
                    ent.set_text(str(current))
                    self.entries[key] = ent
                    self.grid.attach(lbl, 0, i, 1, 1)
                    self.grid.attach(ent, 1, i, 1, 1)
                    if key.endswith("_api_key"):
                        ent.set_visibility(False)
                        show_btn = Gtk.CheckButton(label="Show")
                        show_btn.connect(
                            "toggled",
                            lambda btn, e=ent: e.set_visibility(btn.get_active()),
                        )
                        self.grid.attach(show_btn, 2, i, 1, 1)

    def _persist_settings(self):
        for k, ent in self.entries.items():
            if isinstance(ent, Gtk.ComboBoxText):
                val = ent.get_active_text()
            else:
                val = ent.get_text()
            try:
                ChatWithTreeConfig.save_setting(k, val)
            except (TypeError, ValueError, KeyError):
                import logging

                log = logging.getLogger("ChatWithTreeMCP")
                log.error("Failed to save setting")

    def _build_modeldropdown(self):
        import gi

        gi.require_version("Gtk", "3.0")
        from gi.repository import Gtk

        combo = Gtk.ComboBoxText()
        combo.set_entry_text_column(0)
        for val in self._build_modeldropdown_options():
            combo.append_text(val)
        return combo

    def _build_modeldropdown_options(self):
        options = []
        for provider, models in ChatWithTreeConfig._MODEL_OPTIONS_CACHE.items():
            for mid in models:
                options.append(f"{provider}/{mid}")
        current_model = ChatWithTreeConfig.load_setting("model_name") or ""
        if current_model and current_model not in options:
            options.insert(0, current_model)
        if not options and current_model:
            options = [current_model]
        return options

    def _fetch_and_cache_model_lists(self):
        import logging

        for provider, cfg_key in {
            "openrouter": "openrouter_api_key",
            "openai": "openai_api_key",
            "deepseek": "deepseek_api_key",
            "moonshotai": "moonshotai_api_key",
            "ollama": None,
            "opencode": "opencode_api_key",
        }.items():
            url_val = (
                ChatWithTreeConfig.load_setting("model_url") or "http://localhost:11434"
            )
            key_val = ChatWithTreeConfig.load_setting(cfg_key) if cfg_key else ""
            if cfg_key and not key_val:
                # Skip providers with missing API keys to avoid 401 errors
                ChatWithTreeConfig._MODEL_OPTIONS_CACHE[provider] = []
                import logging

                log = logging.getLogger("ChatWithTreeMCP")
                log.warning(f"[models] provider={provider} skipped (no api_key)")
                continue
            try:
                from llm_client import PROVIDER_REGISTRY, LLMClient

                client = LLMClient()
                reg = PROVIDER_REGISTRY.get(provider)
                base_url = (
                    reg.get("base_url")
                    if reg
                    else (url_val or "http://localhost:11434")
                ) or "http://localhost:11434"
                models_path = (
                    reg.get("models_path", "/v1/models") if reg else "/v1/models"
                )
                url_val = base_url.rstrip("/") + models_path
                endpoint = url_val
                log = logging.getLogger("ChatWithTreeMCP")
                log.warning(
                    f"[models] provider={provider} endpoint={endpoint} url={url_val} key_present={'yes' if key_val else 'no'}"
                )
                fetched = client.list_models(base_url, key_val)
                ChatWithTreeConfig._MODEL_OPTIONS_CACHE[provider] = fetched
                log = logging.getLogger("ChatWithTreeMCP")
                log.warning(
                    f"[models] provider={provider} endpoint={endpoint} fetched={len(fetched)} url={base_url}"
                )
            except (TypeError, ValueError, KeyError) as exc:
                import logging

                log = logging.getLogger("ChatWithTreeMCP")
                log.warning(f"[models] provider={provider} fetch failed: {exc}")
                ChatWithTreeConfig._MODEL_OPTIONS_CACHE[provider] = []

    def on_process_button_clicked(self, widget):
        """
        Callback function when the 'Send' button is clicked or 'Enter' is pressed.
        """
        # Check if the chat_logic instance has been set.
        # This handles the case where the addon is loaded for the first time
        # on an already running Gramps session.
        if self.chat_service is None:
            notInitializedMessage = ReplyItem(
                type=YieldType.FINAL,
                data=ChatResponse(
                    text=_(
                        "The ChatWithTree addon is not yet initialized. \
                    Please reload Gramps or select a database."
                    )
                ),
            )
            self._add_message_row(notInitializedMessage)
            return

        if self.chat_service.is_processing():
            processingMessage = ReplyItem(
                type=YieldType.PARTIAL,
                data=ChatResponse(
                    text=_("The chatbot is currently processing a query. Please wait.")
                ),
            )
            self._add_message_row(processingMessage)
            return
        # Normal handling of user input
        user_input = self.input_entry.get_text()
        self.input_entry.set_text("")
        if user_input.strip():
            userMessage = ReplyItem(
                type=YieldType.USER, data=ChatResponse(text=f"{user_input}")
            )
            self._add_message_row(userMessage)
            # Now, schedule the reply-getting logic to run when the main loop is idle.
            # Run the asynchronous processing for this single query
            try:
                self.current_tool_call_label = None
                # 1. Start the job in the background (non-blocking call)
                self.chat_service.start_query(user_input)

                # queue-checking logic to run repeatedly on the main thread
                # consumes the yielded results from the worker thread
                GLib.idle_add(self._check_queue_for_reply)

            except (TypeError, ValueError, KeyError) as e:
                LOG.error(f"Error running async query: {e}")
                exceptionMsg = ReplyItem(
                    type=YieldType.ERROR,
                    data=ChatResponse(
                        text=_("An error occurred while processing your query.")
                    ),
                )
                self._add_message_row(exceptionMsg)
                return

    def main(self):
        """
        This method is called when the Gramplet needs to update its content.
        """

    def destroy(self):
        """
        Clean up resources when the Gramplet is closed.
        """
        Gramplet.destroy(self)
