#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2025 Melle Koning
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
import inspect
import json
import logging
import re
import sys
import time
from collections.abc import Iterator
from re import Pattern
from typing import Any

from chatwithllm import ChatResponse, EntityMetadata, IChatLogic, ReplyItem, YieldType
from ChatWithTreeConfig import load_key_for_provider, load_setting
from gramps.gen.const import GRAMPS_LOCALE as glocale
from gramps.gen.db.utils import open_database
from gramps.gen.display.name import displayer as name_displayer
from gramps.gen.display.place import displayer as place_displayer
from gramps.gen.lib import Person
from gramps.gen.simple import SimpleAccess
from llm_client import PROVIDER_REGISTRY, LLMClient, resolve_provider
from mcp_utils import make_tool_schema, to_openai_tools

LOG = logging.getLogger(".")


# gramps translation support for this module
_ = glocale.translation.gettext

# interface that we use in the gramplet

HELP_TEXT = """
ChatWithTreeMCP uses Gramps CONFIGMAN settings.

Example model names (need provider prefix):
  ollama/gemma4, openrouter/moonshotai/kimi-k2:free,
  openai/gpt-4o-mini, deepseek/deepseek-chat, gemini/gemini-2.5-flash,
  anthropic/claude-3-sonnet, groq/llama3-8b, mistral/mistral-small

Supported providers (auto-routed): ollama (local), openrouter,
moonshotai, openai, deepseek. `load_setting("model_url")`
For local Ollama provide the URL (default `http://localhost:11434`).

You can find a list of ollama models here:
https://ollama.com/library/

Commands:
/help - show this help text
/history - show the full chat history in JSON format

"""

SYSTEM_PROMPT = """
You are a helpful and highly analytical genealogist, an expert in the Gramps open
source genealogy program.
Your primary goal is to assist the user by providing accurate and relevant
genealogical information.

**Guidelines for Tool Usage and Output:**

1.  **Prioritize User Response:** Always aim to provide a direct answer to the
user's query as soon as you have sufficient information.
2.  **Tool Purpose:** Use tools to gather specific information that directly
 helps answer the user's request.
3.  **About data details from tools:**
    * Use database keys, grampsID keys, or a person's 'handle' for internal
      reference to person data but present data based on retrieved names of persons.
    * Do present names of people to communicate human readable data received from tools
4.  **Progress Monitoring & Self-Correction:**
    * **Assess Tool Results:** After each tool call, carefully evaluate its output.
      Did it provide the expected information?
      Is it sufficient to progress towards the user's goal?
    * **Tool use** Use as many tool calls in one try as you can, but do not call the
    same tool with the same arguments more than once.
5.  **Summarize Findings:** Respond in markdown format prefer lists above tables to
    display all information you have gathered
    and clearly state what you found and what information you were unable to obtain.
"""

# ===
# ChatBot class gets initialized when a Gramps database
# is selected (on db change)
# ===


class ChatBot(IChatLogic):
    def __init__(self, database_name: str):
        self.database_name = database_name
        # Dependency-free, OpenAI-compatible LLM client (replaces litellm).
        self.llm_client = LLMClient(
            model_url=load_setting("model_url"),
            api_key="",
        )
        self.limit_loop = int(load_setting("loop_limit") or 6)  # Read from CONFIGMAN
        # The collector for the current conversation turn
        self.current_entities: dict[str, EntityMetadata] = {}
        self.reset_chat_history()
        self.tool_map = {
            "start_point": self.start_point,
            "get_person": self.get_person,
            "get_family": self.get_family,
            "get_children_of_person": self.get_children_of_person,
            "get_mother_of_person": self.get_mother_of_person,
            "get_father_of_person": self.get_father_of_person,
            "get_person_birth_date": self.get_person_birth_date,
            "get_person_death_date": self.get_person_death_date,
            "get_person_birth_place": self.get_person_birth_place,
            "get_person_death_place": self.get_person_death_place,
            "get_person_event_list": self.get_person_event_list,
            "get_event": self.get_event,
            "get_event_place": self.get_event_place,
            "get_child_in_families": self.get_child_in_families,
            "find_people_by_name": self.find_people_by_name,
        }
        # Canonical MCP-shaped tool schemas (in-process tool registry).
        # Converted to OpenAI format at send-time via to_openai_tools().
        self.tool_definitions = [
            make_tool_schema(func) for func in self.tool_map.values()
        ]

        # This dictionary maps command names to their handler methods
        self.command_handlers = {
            "/help": self.command_handle_help,
            "/history": self.command_handle_history,
        }

    def open_database_for_chat(self) -> None:
        self.db = open_database(self.database_name, force_unlock=True)
        if self.db is None:
            raise RuntimeError(f"Unable to open database {self.database_name}")
        self.sa = SimpleAccess(self.db)

    def _reply(self, y_type: YieldType, text: str, metadata=None) -> ReplyItem:
        """Helper to ensure we always yield a valid NamedTuple ReplyItem."""
        return ReplyItem(
            type=y_type, data=ChatResponse(text=text, metadata=metadata or [])
        )

    def _register_entity(self, handle: str, name: str, etype: str):
        """Adds an entity to the current session if not already present."""
        if handle not in self.current_entities:
            self.current_entities[handle] = EntityMetadata(
                handle=handle, name=name, entity_type=etype
            )

    def reset_chat_history(self) -> None:
        """Resets the chat message history to its initial state."""
        self.messages: list[dict[str, Any]] = [
            {"role": "system", "content": SYSTEM_PROMPT}
        ]

    def command_handle_help(self, message: str) -> Iterator[ReplyItem]:
        url, _, _ = resolve_provider(load_setting("model_name") or "")
        model_name = load_setting("model_name") or ""
        if "/" in model_name:
            provider = model_name.split("/", 1)[0]
        elif not model_name:
            provider = "custom"
        else:
            provider = "unknown"
        yield self._reply(
            YieldType.FINAL,
            f"{HELP_TEXT}"
            f"\nCurrent model: {load_setting('model_name') or '(not set)'}"
            f"\nResolved provider: {provider}"
            f"\nResolved endpoint: {url}",
        )

    def command_handle_history(self, message: str) -> Iterator[ReplyItem]:
        """
        returns the full chat history to the user
        """
        yield self._reply(
            YieldType.FINAL, json.dumps(self.messages, indent=4, sort_keys=True)
        )

    # The implementation of the IChatLogic interface
    def get_reply(self, message: str) -> Iterator[ReplyItem]:
        """
        Processes the message and returns a reply.
        """
        # Strip leading/trailing whitespace
        message = message.strip()
        # Reset the collector for the new prompt
        self.current_entities = {}

        if message.startswith("/"):
            # Split the message into command and arguments (if any)
            command_key = message.split(" ", 1)[0]

            # Look up the command in the dictionary
            commandhandler = self.command_handlers.get(command_key)

            if commandhandler:
                # Call the handler and yield from its generator
                yield from commandhandler(message)
            else:
                # Handle unknown command
                yield self._reply(YieldType.ERROR, f"Unknown command: {command_key}")
            return  # prevent command to be sent to LLM
        if load_setting("model_name"):
            # yield from returns all yields from the calling func
            yield from self.get_chatbot_response(message)
        else:
            yield self._reply(
                YieldType.ERROR,
                "Error: ensure to set model_name in ChatWithTreeConfig settings. ",
            )

    def _llm_complete(
        self,
        all_messages: list[dict[str, str]],
        tool_definitions: list[dict[str, str]] | None,
        seed: int,
    ) -> Any:
        # Uses instance variables resolved once per turn by resolve_model_config()
        response = self.llm_client.completion(
            model=self.resolved_model,
            messages=all_messages,
            tools=tool_definitions,
            tool_choice="auto" if tool_definitions is not None else None,
            seed=seed,
            stream=True,
            model_url=self.resolved_url,
            api_key=self.resolved_key,
        )
        return response

    def resolve_model_config(self) -> None:
        """Resolve model/provider/key/URL once per turn from shared config."""
        model_name = load_setting("model_name") or ""
        url, _, stripped_model = resolve_provider(model_name)

        # What is the provider?r
        provider = model_name.split("/", 1)[0] if "/" in model_name else None
        provider = provider or ("custom" if model_name else None)

        # Get llm provider registry data
        registry_entry = PROVIDER_REGISTRY.get(provider, {}) if provider else {}
        cfg_key = registry_entry.get("key_settings")

        # Determine API key for the provider
        key = None
        if cfg_key and cfg_key.startswith("settings."):
            key = load_setting(cfg_key.replace("settings.", ""))

        # When no config found use fallback
        if not key and provider:
            key = load_key_for_provider(provider)

        # Store found values
        self.resolved_model = stripped_model or model_name or ""
        self.resolved_url = url
        self.resolved_key = key or ""
        self.resolved_provider = provider or "unknown"

        # Refresh LLM client with this config
        self.llm_client = LLMClient(
            model_url=self.resolved_url,
            api_key=self.resolved_key,
        )

    def get_chatbot_response(
        self,
        user_input: str,
        seed: int = 42,
    ) -> Iterator[ReplyItem]:
        self.resolve_model_config()
        self.messages.append({"role": "user", "content": user_input})
        yield from self._llm_loop(seed)

    def execute_tool(self, tool_call):
        # logger.debug(f"Executing tool call: {tool_call['function']['name']}")
        tool_name = tool_call["function"]["name"]
        arguments = json.loads(tool_call["function"]["arguments"])
        sys.stdout.flush()
        tool_func = self.tool_map.get(tool_name)
        try:
            if tool_func is not None:
                sig = inspect.signature(tool_func)
                if len(sig.parameters) == 0:
                    # Ignore any arguments, call with none
                    tool_result = tool_func()
                else:
                    tool_result = tool_func(**arguments)

            else:
                tool_result = f"Unknown tool: {tool_name}"

            content_for_llm = ""
            if isinstance(tool_result, (dict, list)):
                content_for_llm = json.dumps(tool_result)
            else:
                content_for_llm = str(tool_result)

        except Exception as exc:  # noqa: BLE001
            content_for_llm = f"Error in calling tool `{tool_name}`: {exc}"

        self.messages.append(
            {
                "role": "tool",
                "tool_call_id": tool_call["id"],
                "content": content_for_llm,
            }
        )

    def _llm_loop(self, seed: int) -> Iterator[ReplyItem]:
        """Executes the tool-calling loop consistently using SDK object notation."""
        final_response = "I was unable to find the desired information."
        sys.stdout.flush()
        found_final_result = False

        loop_limit = int(load_setting("loop_limit") or 6)
        for count in range(loop_limit):
            time.sleep(1)  # Throttle requests

            messages_for_llm = list(self.messages)
            tools_to_send = to_openai_tools(self.tool_definitions)

            # 1. Log outgoing request
            last_msg = messages_for_llm[-1] if messages_for_llm else {}
            yield self._reply(
                YieldType.TOOL_CALL,
                f"\n-> sending {str(last_msg)[:60]}...",
            )

            # 2. Fetch and validate SDK response
            start_time = time.time()
            response = self._llm_complete(messages_for_llm, tools_to_send, seed)
            duration = time.time() - start_time

            if not response or not response.choices:
                raw_preview = str(getattr(response, "_data", response))[:45]
                yield self._reply(
                    YieldType.TOOL_CALL,
                    f"\n<- response empty: {raw_preview} ({duration:.1f}s)",
                )
                found_final_result = True
                break

            # 3. Extract the message object and persist it
            msg = response.choices[0].message
            self.messages.append(msg.to_dict())

            # 4. Handle Tool Calls cleanly via Object Notation
            if msg.tool_calls:
                yield self._reply(
                    YieldType.TOOL_CALL,
                    f"\n<- received tool call(s) {msg.tool_calls} ({duration:.1f}s)",
                )

                # Safely handle thinking/reasoning blocks vs strategic text
                reasoning = getattr(msg, "reasoning_content", None)
                if reasoning and len(reasoning) > 3:
                    yield self._reply(YieldType.PARTIAL, reasoning)
                elif msg.content and len(msg.content) > 3:
                    yield self._reply(YieldType.PARTIAL, msg.content)

                # Clean iteration over the tool call models
                for tool_call in msg["tool_calls"]:
                    args = tool_call["function"]["arguments"]
                    args_str = args if isinstance(args, str) else json.dumps(args)

                    yield self._reply(
                        YieldType.TOOL_CALL,
                        f" {tool_call['function']['name']}({args_str}) ",
                    )
                    self.execute_tool(tool_call)

            # 5. Handle Final Assistant Answer
            else:
                final_response = msg.content
                found_final_result = True
                if final_response and final_response.strip():
                    yield self._reply(
                        YieldType.TOOL_CALL,
                        f"\n<- received final answer ({duration:.1f}s)",
                    )
                break

        # 6. Fallback loop termination logic
        if not found_final_result:
            messages_for_llm = list(self.messages)
            messages_for_llm.append(
                {
                    "role": "system",
                    "content": "You have reached the maximum number of tool-calling attempts.                 Based on the information gathered so far, provide the most complete answer you can, or clearly state what information you could not obtain. Do not attempt to call any more tools.",
                }
            )
            response = self._llm_complete(messages_for_llm, None, seed)
            if response and response.choices:
                final_response = response.choices[0].message.content

        # Fallback to last message text if final_response is missing/empty
        if (
            final_response == "I was unable to find the desired information."
            and self.messages
        ):
            last_saved = self.messages[-1]
            if isinstance(last_saved, dict) and last_saved.get("content"):
                final_response = last_saved["content"]

        metadata_list = list(self.current_entities.values())
        yield self._reply(YieldType.FINAL, final_response, metadata=metadata_list)

    # Tools:
    def get_person(self, person_handle: str) -> dict[str, Any]:
        """
        Given a person's handle, get the data dictionary of that person,
        including notes.
        """
        person_obj = self.db.get_person_from_handle(person_handle)
        # Check if the person is marked as private
        if person_obj.get_privacy():
            return {"error": "Person data is private and cannot be accessed."}
        data = dict(self.db.get_raw_person_data(person_handle))
        # The idea is that the LLM can use the 'full_name' field
        # to refer to the person in answers
        name1 = name_displayer.display(person_obj)
        data["full_name"] = name1
        self._register_entity(
            handle=person_handle,
            name=name1,
            etype=Person.__name__,  # "Person"
        )
        notes = []
        for note_handle in person_obj.get_note_list():
            note_obj = self.db.get_note_from_handle(note_handle)
            notes.append(note_obj.get())

        if notes:
            data["notes"] = notes

        return data

    def get_mother_of_person(self, person_handle: str) -> dict[str, Any]:
        """
        Given a person's handle, return their mother's data dictionary.
        The person_handle to pass to this func is the "person_handle"
        (a string) for the person
        whose mother you want to find.
        """
        person_obj = self.db.get_person_from_handle(person_handle)
        mother_obj = self.sa.mother(person_obj)
        return self.get_person(mother_obj.handle)

    def get_family(self, family_handle: str) -> dict[str, Any]:
        """
        Get the data of a family given the family handle in the argument.
        * family handles are different from a person handle.
        * a person has family handles in two different fields:
        - "parent_family_list" has the list of family handles the person is a child in
        - "family_list" has the list of family handles the person is a parent in
        The result of "get_family" tool contains several handles as follows:
        "father_handle": person_handle of the father in the family
        "mother_handle": person_handle of the mother in the family
        "child_ref_list": list of person_handles of children in the family,
        each item in the "child_ref_list" has a "ref" which is the person_handle
        of children of the family.
        Details of the persons can be retrieved using the "get_person" tool
        """
        family_data = dict(self.db.get_raw_family_data(family_handle))

        # Add a field for notes 📝
        family_obj = self.db.get_family_from_handle(family_handle)
        notes = []
        for note_handle in family_obj.get_note_list():
            note_obj = self.db.get_note_from_handle(note_handle)
            notes.append(note_obj.get())

        if notes:
            family_data["notes"] = notes

        return family_data

    def start_point(self) -> dict[str, Any]:
        """
        Get the start point of the genealogy tree, i.e., the default person.
        This tool does not take any "arguments".
        * Call this tool without arguments
        * Use this tool to get the first person in the genealogy tree.

        The result of start_point contains values for:
        * The "full_name" contains the name of this person.
        * The "handle" is the key that looks like a hash string for this person
        to use for other tool calls.
        * "family_list" is a list of handles where this person is a parent.
        * "parent_family_list" is a list of handles for the families where this person
        is listed as a child.
        """
        obj = self.db.get_default_person()
        if obj:
            return self.get_person(obj.handle)

        return None

    def get_children_of_person(
        self, person_handle: str
    ) -> list[tuple[str, dict[str, Any]]]:
        """
        Get a list of children handles and their details for a person's main family,
        given a person's handle.

        Returns a list of tuples, where each tuple contains:
        - The child's handle (str)
        - The child's details (dict) as returned by get_person
        """
        obj = self.db.get_person_from_handle(person_handle)
        family_handle_list = obj.get_family_handle_list()
        children_data = []

        if family_handle_list:
            family_id = family_handle_list[0]
            family = self.db.get_family_from_handle(family_id)
            child_handles = [handle.ref for handle in family.get_child_ref_list()]

            for handle in child_handles:
                person_data = self.get_person(
                    handle
                )  # Use the existing get_person tool
                children_data.append((handle, person_data))

        return children_data

    def get_father_of_person(self, person_handle: str) -> dict[str, Any]:
        """
        Given a person's handle, return their father's data dictionary.
        The "person_handle" to pass to this func is the "person_handle" (a string)
        for the person whose father you want to find.
        """
        person_obj = self.db.get_person_from_handle(person_handle)
        father_obj = self.sa.father(person_obj)
        return self.get_person(father_obj.handle)

    def get_person_birth_date(self, person_handle: str) -> str:
        """
        Given a person's handle, return the birth date as a string.
        """
        person = self.db.get_person_from_handle(person_handle)
        return self.sa.birth_date(person)

    def get_person_death_date(self, person_handle: str) -> str:
        """
        Given a person's handle, return the death date as a string.
        """
        person = self.db.get_person_from_handle(person_handle)
        return self.sa.death_date(person)

    def get_person_birth_place(self, person_handle: str) -> str:
        """
        Given a person's handle, return the birth date as a string.
        """
        person = self.db.get_person_from_handle(person_handle)
        return self.sa.birth_place(person)

    def get_person_death_place(self, person_handle: str) -> str:
        """
        Given a person's handle, return the death place as a string.
        """
        person = self.db.get_person_from_handle(person_handle)
        return self.sa.death_place(person)

    def get_person_event_list(self, person_handle: str) -> list[str]:
        """
        Get a list of event handles associated with a person,
        given the person handle. Use `get_event(event_handle)`
        to look up details about an event.
        """
        obj = self.db.get_person_from_handle(person_handle)
        if obj:
            return [ref.ref for ref in obj.get_event_ref_list()]

    def get_event(self, event_handle: str) -> dict[str, Any]:
        """
        Given an event_handle, get the associated data dictionary.
        """
        data = dict(self.db.get_raw_event_data(event_handle))
        return data

    def get_event_place(self, event_handle: str) -> str:
        """
        Given an event_handle, return the associated place string.
        """
        event = self.db.get_event_from_handle(event_handle)
        return place_displayer.display_event(self.db, event)

    def get_child_in_families(self, person_handle: str) -> list[dict[str, Any]]:
        """
        Retrieve detailed information about all families where the given person
        is listed as a child.
        Purpose: identify the person's siblings
        and parents by examining the family structures the person
        belongs to.
        """
        person_obj = self.db.get_person_from_handle(person_handle)
        families = self.sa.child_in(person_obj)
        family_data_list = []

        for family in families:
            family_data = self.get_family(family.handle)
            family_data_list.append(family_data)

        return family_data_list

    def create_search_pattern(self, search_string: str) -> Pattern:
        """
        Creates a case-insensitive regex pattern to match any of the words
        in a given search string, using word boundaries.

        Args:
            search_string: The string containing words to search for.

        Returns:
            A compiled regex Pattern object.
        """
        # 1. Split the search string into individual words.
        search_terms = search_string.split()

        # Handle the case of an empty search string
        if not search_terms:
            # Return a pattern that will not match anything
            return re.compile(r"$^")

        # 2. Escape each term to treat special regex characters as literals.
        escaped_terms = [re.escape(term) for term in search_terms]

        # 3. Join the escaped terms with the regex "OR" operator.
        regex_or_pattern = "|".join(escaped_terms)

        # 4. Add word boundaries to the pattern and compile it.
        final_pattern = re.compile(r"\b(?:" + regex_or_pattern + r")\b", re.IGNORECASE)

        return final_pattern

    def find_people_by_name(self, search_string: str) -> list[dict[str, Any]]:
        """
        Searches the Gramps database for people whose primary or alternate names
        contain the given search string.

        Argument:
            One string to match in person names.

        Returns:
            A list of dictionaries, where each dictionary contains the raw data
            of a matching person.

         Example:
            To find people named "Chris Woods", call the tool with:
            find_people_by_name(search_string="Chris Woods")
        """
        matching_people_raw_data = []
        search_pattern = self.create_search_pattern(search_string)

        for person_obj in self.sa.all_people():
            matched = False

            # Helper function to check fields within a Name or Surname object
            def check_name_fields(name_or_surname_obj: Any) -> bool:
                """
                Checks relevant string fields of a Name or Surname object for a match.
                """
                fields_to_check = []

                # Fields common to Name object (primary_name or alternate_name elements)
                if hasattr(name_or_surname_obj, "first_name"):
                    fields_to_check.append(name_or_surname_obj.first_name)
                # Corrected: 'prefix' and 'suffix' are properties of the
                # Name object itself, not the Surname object.
                if hasattr(name_or_surname_obj, "prefix"):
                    fields_to_check.append(name_or_surname_obj.prefix)
                if hasattr(name_or_surname_obj, "suffix"):
                    fields_to_check.append(name_or_surname_obj.suffix)
                if hasattr(name_or_surname_obj, "title"):
                    fields_to_check.append(name_or_surname_obj.title)
                if hasattr(name_or_surname_obj, "call"):
                    fields_to_check.append(name_or_surname_obj.call)
                if hasattr(name_or_surname_obj, "nick"):
                    fields_to_check.append(name_or_surname_obj.nick)
                if hasattr(name_or_surname_obj, "famnick"):
                    fields_to_check.append(name_or_surname_obj.famnick)
                if hasattr(name_or_surname_obj, "patronymic"):
                    fields_to_check.append(name_or_surname_obj.patronymic)

                # Fields specific to Surname object (within surname_list)
                if hasattr(name_or_surname_obj, "surname"):
                    fields_to_check.append(name_or_surname_obj.surname)
                    # Note: Surname objects can also have their
                    # own 'prefix' and 'connector'
                    # which are separate from the 'prefix'
                    # of the main Name object.
                    if hasattr(name_or_surname_obj, "connector"):
                        fields_to_check.append(name_or_surname_obj.connector)

                for field_value in fields_to_check:
                    # Ensure field_value is a non-empty string before attempting search
                    if (
                        isinstance(field_value, str)
                        and field_value
                        and search_pattern.search(field_value)
                    ):
                        return True
                return False

            # Check primary name fields
            if person_obj.primary_name:
                if check_name_fields(person_obj.primary_name):
                    matched = True

                # Surnames are in a list, iterate through each Surname object
                if not matched and hasattr(person_obj.primary_name, "surname_list"):
                    for surname_obj in person_obj.primary_name.surname_list:
                        if check_name_fields(surname_obj):
                            matched = True
                            break

            # Check alternate name fields if not already matched
            if (
                not matched
                and hasattr(person_obj, "alternate_names")
                and person_obj.alternate_names
            ):
                for alt_name in person_obj.alternate_names:
                    if check_name_fields(alt_name):
                        matched = True
                        break

                    # Check surnames within alternate name
                    if not matched and hasattr(alt_name, "surname_list"):
                        for alt_surname_obj in alt_name.surname_list:
                            if check_name_fields(alt_surname_obj):
                                matched = True
                                break
                        if matched:  # Break from outer alt_names loop if matched
                            break

            if matched:
                # Use the existing _get_raw_person_from_id_data to get raw data
                # self.db is assumed to be the database access object within
                # the tool's class.
                raw_data = dict(
                    self.db._get_raw_person_from_id_data(person_obj.gramps_id)
                )
                desired_fields = {
                    "handle": raw_data.get("handle"),
                    "first_name": raw_data.get("primary_name", {}).get("first_name"),
                    "surname": raw_data.get("primary_name", {})
                    .get("surname_list", [{}])[0]
                    .get("surname"),
                    "prefix": raw_data.get("primary_name", {})
                    .get("surname_list", [{}])[0]
                    .get("prefix"),
                }
                matching_people_raw_data.append(desired_fields)

        return matching_people_raw_data
