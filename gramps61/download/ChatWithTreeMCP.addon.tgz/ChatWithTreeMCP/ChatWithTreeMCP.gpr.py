# ------------------------------------------------------------------------
#
# Register the Gramplet ChatWithTreeMCP
#
# ------------------------------------------------------------------------
register(
    VIEW,
    id="ChatWithTreeMCP",
    name=_("Chat With Tree Interactive Addon (MCP)"),
    description=_("Chat With Tree using an in-process MCP-style tool service and a Large Language Model. Uses only the Python standard library (no extra modules required)."),
    version = '0.1.7',
    gramps_target_version="6.1",
    status=STABLE,
    audience=EVERYONE,
    fname="ChatWithTreeMCP.py",
    viewclass="ChatWithTreeMCPClass",
    category=("Dashboard", _("Dashboard")),
    order=START,
    authors = ["Melle Koning"],
    authors_email = ["mellekoning@gmail.com"],
    help_url="Addon:ChatWithTree",
)
