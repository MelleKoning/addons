# ChatWithTree.py
import logging
LOG = logging.getLogger(".")
LOG.warning("loading chatwithtree")
# ==============================================================================
# Standard Python libraries
# ==============================================================================
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk
from gi.repository import GLib

# ==============================================================================
# GRAMPS API
# ==============================================================================
from gramps.gen.plug import Gramplet
from gramps.gen.const import GRAMPS_LOCALE as glocale
_ = glocale.get_addon_translator(__file__).gettext

from chatwithllm import IChatLogic, ChatWithLLM

try:
    from chatbot import ChatBot
except ImportError as e:
    LOG.warning(e)
    raise ImportError("Failed to import ChatBot from chatbot module: " + str(e))

LOG.warning("after import ChatBot")

# ==============================================================================
# Gramplet Class Definition
# ==============================================================================
class ChatWithTreeClass(Gramplet):
    """
    A simple interactive Gramplet that takes user input and provides a reply.

    This version uses a Gtk.ListBox to create a dynamic, chat-like interface
    with styled message "balloons" for user input and system replies.
    """
    
    def __init__(self, parent=None, **kwargs):
        """
        The constructor for the Gramplet.
        We call the base class constructor here. The GUI is built in the
        init() method.
        """
        # Call the base class constructor. This is a mandatory step.
        Gramplet.__init__(self, parent, **kwargs)

    def init(self):
        """
        This method is called by the Gramps framework after the Gramplet
        has been fully initialized. We build our GUI here.
        """
        # Build our custom GUI widgets.
        self.vbox = self._build_gui()

        # The Gramplet's container widget is found via `self.gui`.
        # We first remove the default textview...
        self.gui.get_container_widget().remove(self.gui.textview)
        # ... and then we add our new vertical box.
        self.gui.get_container_widget().add(self.vbox)

        # Show all widgets.
        self.vbox.show()
        # Instantiate the chat logic class. This decouples the logic from the UI.
        # Choose ChatWIthLLM for simple reverse chat
        # self.chat_logic = ChatWithLLM()
        # Choose Chatbot for chat with Tree
        self.chat_logic = ChatBot()


    def _build_gui(self):
        """
        Creates all the GTK widgets for the Gramplet's user interface.
        Returns the top-level container widget.
        """
        # Create the main vertical box to hold all our widgets.
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        
        # -------------------
        # 1. Chat History Section
        # -------------------
        # We use a Gtk.ListBox to hold our chat "balloons".
        self.chat_listbox = Gtk.ListBox()
        # Set a name for CSS styling.
        self.chat_listbox.set_name("chat-listbox")
        # Ensure the listbox is a single-column list.
        self.chat_listbox.set_selection_mode(Gtk.SelectionMode.NONE)
        
        # We need a reference to the scrolled window to control its scrolling.
        self.scrolled_window = Gtk.ScrolledWindow()
        self.scrolled_window.set_hexpand(True)
        self.scrolled_window.set_vexpand(True)
        self.scrolled_window.add(self.chat_listbox)
        vbox.pack_start(self.scrolled_window, True, True, 0)
        
        # Apply CSS styling for the chat balloons.
        self._apply_css_styles()

        # -------------------
        # 2. Input Section
        # -------------------
        input_hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)

        self.input_entry = Gtk.Entry()
        self.input_entry.set_placeholder_text(_("Type a message..."))
        self.input_entry.connect("activate", self.on_process_button_clicked)
        input_hbox.pack_start(self.input_entry, True, True, 0)

        self.process_button = Gtk.Button(label=_("Send"))
        self.process_button.connect("clicked", self.on_process_button_clicked)
        input_hbox.pack_start(self.process_button, False, False, 0)

        vbox.pack_start(input_hbox, False, False, 0)

        # Add the initial message to the list box.
        self._add_message_row(_("Chat with Tree initialized."), is_user_message=False)
        
        return vbox

    def _apply_css_styles(self):
        """
        Defines and applies CSS styles to the Gramplet's widgets.
        """
        css_provider = Gtk.CssProvider()
        css = """
        #chat-listbox {
            background-color: white;
        }
        .message-box {
            background-color: #f0f0f0; /* Default background */
            padding: 10px;
            margin: 5px;
            border-radius: 15px;
        }
        .user-message-box {
            background-color: #dcf8c6; /* Light green for user messages */
        }
        .tree-reply-box {
            background-color: #d1e2f4; /* Light blue for replies */
        }
        """
        css_provider.load_from_data(css.encode('utf-8'))
        screen = Gdk.Screen.get_default()
        context = Gtk.StyleContext()
        context.add_provider_for_screen(screen, css_provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        
        # We need to set up a style context on the chat listbox
        style_context = self.chat_listbox.get_style_context()
        style_context.add_class("message-box") # This won't work on the listbox itself, but it's good practice.

    def _add_message_row(self, text, is_user_message):
        """
        Creates a new message "balloon" widget and adds it to the listbox.
        """
        # Create a horizontal box to act as the message container.
        hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        hbox.set_spacing(6)
        
        # Create the message "balloon" box.
        message_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        message_box.get_style_context().add_class("message-box")

        # Create the label for the text.
        message_label = Gtk.Label(label=text)
        message_label.set_halign(Gtk.Align.START)
        message_label.set_line_wrap(True)
        message_label.set_max_width_chars(50) # Limit width to prevent it from spanning the entire window.
        message_box.pack_start(message_label, True, True, 0)

        if is_user_message:
            message_box.get_style_context().add_class("user-message-box")
            # Align the message balloon to the right.
            hbox.set_halign(Gtk.Align.END)
        else:
            message_box.get_style_context().add_class("tree-reply-box")
            # Align the message balloon to the left.
            hbox.set_halign(Gtk.Align.START)

        # Add the message balloon to the main horizontal container.
        hbox.add(message_box)

        # Add the whole row to the listbox.
        self.chat_listbox.add(hbox)
        self.chat_listbox.show_all()

        # --- GTK3-compatible scrolling ---
        # Get the vertical adjustment from the ScrolledWindow.
        adj = self.scrolled_window.get_vadjustment()
        # Set the adjustment's value to the maximum, which scrolls to the end.
        adj.set_value(adj.get_upper() - adj.get_page_size())
        # --- End GTK3-compatible scrolling ---

    def on_process_button_clicked(self, widget):
        """
        Callback function when the 'Send' button is clicked or 'Enter' is pressed.
        """
        user_input = self.input_entry.get_text()

        if user_input.strip():
            # Add the user's message to the chat.
            self._add_message_row(f"You: {user_input}", is_user_message=True)

            # Process the text and add the reply.
            reply = self.chat_logic.get_reply(user_input)
            self._add_message_row(reply, is_user_message=False)

            # Clear the input entry after sending.
            self.input_entry.set_text("")
        else:
            # If input is empty, just clear the entry.
            self.input_entry.set_text("")
            
    def main(self):
        """
        This method is called when the Gramplet needs to update its content.
        """
        pass

    def destroy(self):
        """
        Clean up resources when the Gramplet is closed.
        """
        Gramplet.destroy(self)
