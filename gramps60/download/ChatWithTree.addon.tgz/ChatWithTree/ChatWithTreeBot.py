import logging
LOG = logging.getLogger(".")
LOG.warning("loading chatbot file")

try:
    from typing import Dict, Any, List, Optional, Tuple
    import os
    import json
    import sys
    import time
    import re
    import inspect
    import litellm
except ImportError as e:
    LOG.warning(e)
    raise Exception("ChatWithTree requires litellm")
# import markdown
LOG.warning("after typing")

litellm.drop_params = True

from gramps.gen.plug import Gramplet
from gramps.gen.const import GRAMPS_LOCALE as glocale
from gramps.gen.simple import SimpleAccess
from gramps.gen.db.utils import open_database
from gramps.gen.display.place import displayer as place_displayer
from gramps.gen.config import CONFIGMAN

# gramps translation support for this module
_ = glocale.translation.gettext
LOG.warning("after glocale")

# interface that we use in the gramplet
from chatwithllm import IChatLogic
LOG.warning("after IChatLogic")

HELP_TEXT = """
ChatWithTree uses the following OS environment variables:

```
export GRAMPS_AI_MODEL_NAME="<ENTER MODEL NAME HERE>"
```

This is always needed. Examples: "ollama/deepseek-r1:1.5b", "openai/gpt-4o-mini", "gemini/gemini-2.5-flash"

```
export GRAMPS_AI_MODEL_URL="<ENTER URL HERE>"
```

This is needed if running your own LLM server. Example: "http://127.0.0.1:8000"

You can find a list of litellm providers here:
https://docs.litellm.ai/docs/providers

You can find a list of ollama models here:
https://ollama.com/library/deepseek-r1:1.5b

### Optional

If you are running a commercial AI model provider, you will need their API key.

#### Example

For OpenAI:

```
export OPENAI_API_KEY="sk-..."
```

For Gemini:

```
export GEMINI_API_KEY="gemini-key..."
```

"""

SYSTEM_PROMPT = """
You are a helpful and highly analytical genealogist, an expert in the Gramps open source genealogy program.
Your primary goal is to assist the user by providing accurate and relevant genealogical information.

**Crucial Guidelines for Tool Usage and Output:**

1.  **Prioritize User Response:** Always aim to provide a direct answer to the user's query as soon as you have sufficient information.
2.  **Tool Purpose:** Use tools ONLY when necessary to gather specific information that directly helps answer the user's request.
3.  **About data details from tools:**
    * Never mention database keys, grampsID keys, or a person's 'handle' directly to the user.
    * Do present names of people to communicate human readable data received from tools
4.  **Progress Monitoring & Self-Correction:**
    * **Assess Tool Results:** After each tool call, carefully evaluate its output. Did it provide the expected information?
      Is it sufficient to progress towards the user's goal?
    * **Avoid Redundancy:** Do not call the same tool twice in a row.
    * **Avoid looping:** If you have made 2-3 consecutive tool calls that do not significantly advance towards the
       user's question, or if you encounter persistent errors, assume you are stuck or lacking the necessary data and stop.
5.  **Graceful Exit with Partial Results:**
    * **If Stuck or Unable to Progress:** If you can not make progress, or have made several unproductive tool calls, **stop attempting further tool calls immediately.**
    * **Summarize Findings:** Instead, synthesize all the information you *have* gathered so far, even if it's incomplete or not directly leading to a full answer. Clearly state what you found and what information you were unable to obtain.

You can get the start point of the genealogy tree using the `start_point` tool.
"""

GRAMPS_AI_MODEL_NAME = os.environ.get("GRAMPS_AI_MODEL_NAME")
GRAMPS_AI_MODEL_URL = os.environ.get("GRAMPS_AI_MODEL_URL")
# overwrite the default database path in case the env variable is set
# GRAMPS_DB_LOCATION = os.environ.get("GRAMPS_DB_LOCATION")

from litellm_utils import function_to_litellm_definition
LOG.warning("after litellm_utils")

class ChatBot(IChatLogic):
    def __init__(self):
        #if self.db is None:
        #    raise Exception(f"Unable to open database {database_name}")
        self.messages = []
        # initialize chat history with system prompt
        self.messages.append({"role": "system", "content": SYSTEM_PROMPT})
        LOG.warning("Chatbot init")
        #self.sa = SimpleAccess(self.db)
        #self.tool_map = {
        #    "start_point": self.start_point,
        #    "get_person": self.get_person,
        #    "get_family": self.get_family,
        #    "get_children_of_person": self.get_children_of_person,
        #    "get_mother_of_person": self.get_mother_of_person,
        #    "get_father_of_person": self.get_father_of_person,
        #    "get_person_birth_date": self.get_person_birth_date,
        #    "get_person_death_date": self.get_person_death_date,
        #    "get_person_birth_place": self.get_person_birth_place,
        #    "get_person_death_place": self.get_person_death_place,
        #    "get_person_event_list": self.get_person_event_list,
        #    "get_event": self.get_event,
        #    "get_event_place": self.get_event_place,
        #    "get_child_in_families": self.get_child_in_families,
        #    "find_people_by_name": self.find_people_by_name,
        #}
        #self.tool_definitions = [
        #    function_to_litellm_definition(func) for func in self.tool_map.values()
        #]


    # The implementation of the IChatLogic interface
    def get_reply(self, message: str) -> str:
        """
        Processes the message and returns a reply.
        In this initial version, it simply reverses the input text.
        """
        return "pindakaas"



    