"""DDD Provider Repository — CONFIGMAN-backed layer for ChatWithTreeMCP.
Aggregate root: provider name. Storage: Gramps CONFIGMAN.
Rest of plugin addresses this repo, not CONFIGMAN directly (Option B).
"""
from typing import Optional

try:
    from gramps.gen import config
except Exception:  # pragma: no cover — allows syntax check outside Gramps
    config = None  # type: ignore


class ProviderConfig:
    def __init__(
        self,
        provider_name: str,
        api_key: str = "",
        base_url: str = "",
        chat_path: str = "/v1/chat/completions",
        models_path: str = "/v1/models",
        supported_models: Optional[list] = None,
    ):
        self.provider_name = provider_name
        self.api_key = api_key
        self.base_url = base_url
        self.chat_path = chat_path
        self.models_path = models_path
        self.supported_models = supported_models or []


class ProviderRepository:
    """Layer around Gramps CONFIGMAN for AI-provider settings."""

    def __init__(self, manager=None):
        if manager is not None:
            self._cfg = manager
        elif config is not None and hasattr(config, "register_manager"):
            try:
                self._cfg = config.register_manager("ChatWithTreeMCP")
            except Exception:
                self._cfg = None
        else:
            self._cfg = None  # type: ignore

    def _key(self, provider: str, field: str) -> str:
        return f"settings.{provider}_{field}"

    def get_provider(self, provider_name: str) -> ProviderConfig:
        cfg = self._cfg
        if cfg is None:
            return ProviderConfig(provider_name)
        # Read from CONFIGMAN; keys follow settings.{provider}_* pattern
        api_key = cfg.get(self._key(provider_name, "api_key")) or ''
        base_url = cfg.get(self._key(provider_name, "url")) or ''
        chat_path = cfg.get(
            self._key(provider_name, "chat_path")
        ) or "/v1/chat/completions"
        models_path = cfg.get(self._key(provider_name, "models_path")) or "/v1/models"
        return ProviderConfig(
            provider_name=provider_name,
            api_key=api_key,
            base_url=base_url,
            chat_path=chat_path,
            models_path=models_path,
        )

    def add_provider(self, provider_name: str, config: ProviderConfig) -> None:
        self.update_api_key(provider_name, config.api_key)
        self.update_endpoint(
            provider_name, config.base_url,
            config.chat_path, config.models_path,
        )

    def remove_provider(self, provider_name: str) -> None:
        # Clear stored keys for provider (best-effort via CONFIGMAN)
        cfg = self._cfg
        if cfg is None:
            return
        for suffix in ("api_key", "url", "chat_path", "models_path"):
            try:
                cfg.set(self._key(provider_name, suffix), "")
            except Exception:
                pass

    def update_api_key(self, provider_name: str, api_key: str) -> None:
        cfg = self._cfg
        if cfg is not None:
            cfg.set(self._key(provider_name, "api_key"), api_key)

    def update_endpoint(
        self, provider_name: str,
        base_url: str = "", chat_path: str = "",
        models_path: str = "",
    ) -> None:
        cfg = self._cfg
        if cfg is not None:
            if base_url:
                cfg.set(self._key(provider_name, "url"), base_url)
            if chat_path:
                cfg.set(self._key(provider_name, "chat_path"), chat_path)
            if models_path:
                cfg.set(self._key(provider_name, "models_path"), models_path)

    def get_models(self, provider_name: str) -> list:
        # For now return cached list; endpoint call can be added later
        prov = self.get_provider(provider_name)
        # If a future implementation fetches via list_models(url,key), add here.
        return prov.supported_models

    def get_all_providers(self) -> dict:
        # Best-effort: scan known keys; extend as needed
        result = {}
        # Known providers based on current ChatWithTreeConfig keys
        for name in (
            "openrouter", "openai", "ollama", "deepseek",
            "moonshotai", "gemini", "anthropic", "opencode",
        ):
            prov = self.get_provider(name)
            if prov.api_key or prov.base_url:
                result[name] = prov
        return result
