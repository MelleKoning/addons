# ------------------------------------------------------------------------
#
# Register the Gramplet ChatWithTreeMCP
#
# ------------------------------------------------------------------------
register(
    GRAMPLET,
    id="ChatWithTreeMCP",
    name=_("Chat With Tree Interactive Addon (MCP)"),
    description=_("Chat With Tree using an in-process MCP-style tool service and a Large Language Model. Uses only the Python standard library (no extra modules required)."),
    version = '0.1.34',
    gramps_target_version="6.0",
    status=STABLE,
    audience=EVERYONE,
    fname="ChatWithTreeMCP.py",
    gramplet="ChatWithTreeMCPClass",
    gramplet_title=_("Chat With Tree"),
    authors = ["Melle Koning"],
    authors_email = ["mellekoning@gmail.com"],
    height=500,
    navtypes=["Dashboard"],
    category="Dashboard",
    help_url="Addon:ChatWithTree",
)
